# RxShield AI

**Scan Smart. Take Right. Protect Everyone.**

A medication-safety demo built for a hackathon (SDG 3: Good Health and Well-Being).

**Live demo:** https://YOUR-USERNAME.github.io/rxshield-ai/

## Features
- Simulated prescription scanner with a deliberate OCR error the user must correct
- Dose tracking (taken / missed / undo) with audit history
- Safety Ring, Missed-Dose Guard and a printable Handoff Card for pharmacists or doctors
- Rule-based side-effect check (GREEN / AMBER / RED)
- Fictional community analytics and demo directory
- English / Tamil navigation, dark/light theme, large text, reduced motion

## Run locally
Open `index.html` in any browser. No build step, no API keys.

## Limitations
- Demo only. Not a clinical service and not medical advice.
- OCR is simulated; uploaded files are previewed, never read.
- All analytics and directory data are fictional.
- Data is stored in browser localStorage, which is not secure for real health records.
